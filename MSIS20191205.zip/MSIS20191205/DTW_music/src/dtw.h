
unsigned char music_match(unsigned char F1[50],unsigned char F2[50],unsigned char F3[50],unsigned char F4[50],unsigned char F5[50],unsigned char R[50]);

unsigned char score_match(unsigned char F1[50],unsigned char F2[50],unsigned char F3[50],unsigned char F4[50],unsigned char F5[50],unsigned char R[50]);
